#' Internal code objects
#'
#' These are not to be called by the user (or in some cases are just
#' waiting for proper documentation to be written ).
#' @name IsoplotR-internal
#' @keywords internal
NULL
