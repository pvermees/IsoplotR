#' @title Set up U-series disequilibrium correction for U-Pb
#'     geochronology
#' 
#' @description The U-Pb method conventionally assumes initial secular
#'     equilibrium of all the intermediate daughters of the
#'     \eqn{{}^{238}}U-\eqn{{}^{206}}Pb and
#'     \eqn{{}^{235}}U-\eqn{{}^{207}}Pb decay chains.  Violation of
#'     this assumption may produce inaccurate results.  \code{diseq}
#'     sets up initial disequilibrium parameters that are subsequently
#'     passed on to the \code{read.data} function for incorporation in
#'     other functions.
#'
#' @details
#' There are three ways to correct for the initial disequilibrium
#' between the activity of \eqn{{}^{238}}U, \eqn{{}^{234}}Th,
#' \eqn{{}^{230}}Th, and \eqn{{}^{226}}Ra; or between \eqn{{}^{235}}U
#' and \eqn{{}^{231}}Pa:
#'
#' \enumerate{
#' 
#' \item{Specify the assumed initial activity ratios and calculate how
#' much excess \eqn{{}^{206}}Pb and \eqn{{}^{207}}Pb these would have
#' produced.}
#' 
#' \item{Measure the current activity ratios to infer the initial
#' ratios.  This approach only works for young samples.}
#' 
#' \item{The initial \eqn{{}^{230}}Th/\eqn{{}^{238}}U activity ratio
#' can also be estimated by providing the Th/U-ratio of the magma.}
#' 
#' }
#'
#' @param U48 a list containing three items (\code{x}, \code{sx} and
#'     \code{option}) specifying the \eqn{{}^{234}}U/\eqn{{}^{238}}U
#'     disequilibrium.
#'
#' If \code{option=0}, then \code{x} and \code{sx} are ignored and no
#'     disequilibrium correction is applied.
#'
#' If \code{option=1}, then \code{x} contains the initial
#'     \eqn{{}^{234}}U/\eqn{{}^{238}}U ratio.
#'
#' If \code{option=2}, then \code{x} contains the measured
#'     \eqn{{}^{234}}U/\eqn{{}^{238}}U ratio.
#'
#' @param ThU a list containing three items (\code{x}, \code{sx} and
#'     \code{option}) specifying the \eqn{{}^{230}}Th/\eqn{{}^{238}}U
#'     disequilibrium.
#'
#' If \code{option=0}, then \code{x} and \code{sx} are ignored and no
#'     disequilibrium correction is applied.
#'
#' If \code{option=1}, then \code{x} contains the initial
#'     \eqn{{}^{230}}Th/\eqn{{}^{238}}U ratio.
#'
#' If \code{option=2}, then \code{x} contains the measured
#'     \eqn{{}^{230}}Th/\eqn{{}^{238}}U ratio.
#'
#' If \code{option=3}, then \code{x} contains the measured Th/U ratio
#'     of the magma (assumed or determined from the whole rock or
#'     volcanic glass). This only applies for Th-bearing U-Pb data
#'     formats 7 and 8.
#'
#' @param RaU a list containing three items (\code{x}, \code{sx} and
#'     \code{option}) specifying the \eqn{{}^{226}}Ra/\eqn{{}^{238}}U
#'     disequilibrium.
#'
#' If \code{option=0}, then \code{x} and \code{sx} are ignored and no
#'     disequilibrium correction is applied.
#'
#' If \code{option=1}, then \code{x} contains the initial
#'     \eqn{{}^{226}}Ra/\eqn{{}^{238}}U ratio.
#'
#' If \code{option=2}, then \code{x} contains the measured
#'     \eqn{{}^{226}}Ra/\eqn{{}^{238}}U ratio.
#' 
#' @param PaU a list containing three items (\code{x}, \code{sx} and
#'     \code{option}) specifying the \eqn{{}^{231}}Pa/\eqn{{}^{235}}U
#'     disequilibrium.
#'
#' If \code{option=0}, then \code{x} and \code{sx} are ignored and no
#'     disequilibrium correction is applied.
#'
#' If \code{option=1}, then \code{x} contains the initial
#'     \eqn{{}^{231}}Pa/\eqn{{}^{235}}U ratio.
#'
#' If \code{option=2}, then \code{x} contains the measured
#'     \eqn{{}^{231}}Ra/\eqn{{}^{235}}U ratio.
#' 
#' @return a list with the activity ratios, an eigen composition of
#'     the decay contant matrix and the atomic abundances of the
#'     parent and (intermediate) daughter nuclides
#' 
#' @examples
#' d <- diseq(U48=list(x=0,option=1),ThU=list(x=2,option=1),
#'            RaU=list(x=2,option=1),PaU=list(x=2,option=1))
#' fn <- system.file("diseq.csv",package="IsoplotR")
#' UPb <- read.data(fn,method='U-Pb',format=2)
#' concordia(UPb,type=2,show.age=1)
#' @export
diseq <- function(U48=list(x=1,sx=0,option=0),
                  ThU=list(x=1,sx=0,option=0),
                  RaU=list(x=1,sx=0,option=0),
                  PaU=list(x=1,sx=0,option=0)){
    out <- list()
    class(out) <- 'diseq'
    out$U48 <- U48
    out$ThU <- ThU
    out$RaU <- RaU
    out$PaU <- PaU
    out$equilibrium <- check.equilibrium(d=out)
    l38 <- settings('lambda','U238')[1]
    l34 <- settings('lambda','U234')[1]*1000
    l30 <- settings('lambda','Th230')[1]*1000
    l26 <- settings('lambda','Ra226')[1]*1000
    l35 <- settings('lambda','U235')[1]
    l31 <- settings('lambda','Pa231')[1]*1000
    out$Q <- matrix(0,8,8)
    out$Q[1,1] <- -((l26-l38)*(l30-l38)*(l34-l38))/(l26*l30*l34)
    out$Q[2,1] <- -(l38*(l26-l38)*(l30-l38))/(l26*l30*l34)
    out$Q[2,2] <- -((l26-l34)*(l30-l34))/(l26*l30)
    out$Q[3,1] <- -(l38*(l26-l38))/(l26*l30)
    out$Q[3,2] <- -(l34*(l26-l34))/(l26*l30)
    out$Q[3,3] <- -(l26-l30)/l26
    out$Q[4,1] <- -l38/l26
    out$Q[4,2] <- -l34/l26
    out$Q[4,3] <- -l30/l26
    out$Q[4,4] <- -1
    out$Q[5,1:5] <- 1
    out$Q[6,6] <- -(l31-l35)/l31
    out$Q[7,6] <- -l35/l31
    out$Q[7,7] <- -1
    out$Q[8,6:8] <- 1
    out$Qinv <- matrix(0,8,8)
    out$Qinv[1,1] <- -(l26*l30*l34)/((l26-l38)*(l30-l38)*(l34-l38))
    out$Qinv[2,1] <- (l26*l30*l38)/((l26-l34)*(l30-l34)*(l34-l38))
    out$Qinv[2,2] <- -(l26*l30)/((l26-l34)*(l30-l34))
    out$Qinv[3,1] <- -(l26*l34*l38)/((l26-l30)*(l30-l34)*(l30-l38))
    out$Qinv[3,2] <- (l26*l34)/((l26-l30)*(l30-l34))
    out$Qinv[3,3] <- -l26/(l26-l30)
    out$Qinv[4,1] <- (l30*l34*l38)/((l26-l30)*(l26-l34)*(l26-l38))
    out$Qinv[4,2] <- -(l30*l34)/((l26-l30)*(l26-l34))
    out$Qinv[4,3] <- l30/(l26-l30)
    out$Qinv[4,4] <- -1
    out$Qinv[5,1:5] <- 1
    out$Qinv[6,6] <- -l31/(l31-l35)
    out$Qinv[7,6] <- l35 /(l31-l35)
    out$Qinv[7,7] <- -1
    out$Qinv[8,6:8] <-1
    out$L <- c(l38,l34,l30,l26,0,l35,l31,0)
    out$n0 <- rep(0,8)
    nuclides <- c('U238','U234','Th230','Ra226',
                  'Pb206','U235','Pa231','Pb207')
    names(out$L) <- nuclides
    names(out$n0) <- nuclides
    out
}

#' @export
`[.diseq` <- function(x,i){
    out <- x
    for (ratio in c('U48','ThU','RaU','PaU')){
        j <- min(length(out[[ratio]]$x),i)
        out[[ratio]]$x <- out[[ratio]]$x[j]
    }
    out
}

# infer initial activity ratios from Th/U measurements
copy_diseq <- function(x,d=diseq()){
    out <- d
    if (d$ThU$option==3){
        if (x$format>6){
            U <- settings('iratio','U238U235')[1]
            out$ThU$x <- (x$x[,'Th232U238']/d$ThU$x)*U/(1+U)
        }
        out$ThU$option <- 1
    }
    out
}

geomean.diseq <- function(x,...){
    out <- x
    for (ratio in c('U48','ThU','RaU','PaU')){
        out[[ratio]]$x <- geomean(x[[ratio]]$x,...)
    }
    out
}

# to infer initial 38,34,30,35 from measured 34/38 and 30/38
mexp.8405 <- function(){
    l38 <- settings('lambda','U238')[1]
    l34 <- settings('lambda','U234')[1]*1000
    l30 <- settings('lambda','Th230')[1]*1000
    l35 <- settings('lambda','U235')[1]
    out <- list()
    out$L <- c(l38,l34,l30,l35)
    names(out$L) <- c('U238','U234','Th230','U235')
    out$Q <- diag(1,4,4)
    out$Q[1,1] <- (l30-l38)*(l34-l38)/(l34*l38)
    out$Q[2,1] <- (l30-l38)/l34
    out$Q[2,2] <- (l30-l34)/l34
    out$Q[3,1:2] <- 1
    out$Qinv <- diag(1,4,4)
    out$Qinv[1,1] <- (l34*l38)/((l30-l38)*(l34-l38))
    out$Qinv[2,1] <- -(l34*l38)/((l30-l34)*(l34-l38))
    out$Qinv[2,2] <- l34/(l30-l34)
    out$Qinv[3,1] <- (l34*l38)/((l30-l34)*(l30-l38))
    out$Qinv[3,2] <- -l34/(l30-l34)
    out
}

# to infer initial 38,34,35 from measured 34/38
mexp.845 <- function(nratios=3){
    l38 <- settings('lambda','U238')[1]
    l34 <- settings('lambda','U234')[1]*1000
    l30 <- settings('lambda','Th230')[1]*1000
    l26 <- settings('lambda','Ra226')[1]*1000
    l35 <- settings('lambda','U235')[1]
    out <- list()
    out$L <- c(l38,l34,l35)
    names(out$L) <- c('U238','U234','U235')
    out$Q <- diag(1,3,3)
    out$Q[1,1] <- (l34-l38)/l38
    out$Q[2,1] <- 1
    out$Qinv <- diag(1,3,3)
    out$Qinv[1,1] <- l38/(l34-l38)
    out$Qinv[2,1] <- -l38/(l34-l38)
    out
}

reverse <- function(tt,mexp,nt){
    out <- as.vector(mexp$Q %*% diag(exp(mexp$L*tt)) %*% mexp$Qinv %*% nt)
    names(out) <- names(nt)
    out
}
forward <- function(tt,d=diseq(),derivative=0){
    if (derivative==0){
        out <- as.vector(d$Q %*% diag(exp(-d$L*tt)) %*% d$Qinv %*% d$n0)
    } else if (derivative==1){
        out <- as.vector(d$Q %*% diag(exp(-d$L)) %*%
                         diag(exp(-d$L*tt)) %*% d$Qinv %*% d$n0)
    } else if (derivative==2){
        out <- as.vector(d$Q %*% diag(exp(-d$L)) %*% diag(exp(-d$L)) %*%
                         diag(exp(-d$L*tt)) %*% d$Qinv %*% d$n0)
    }
    names(out) <- names(d$L)
    out
}

fix.diseq <- function(d=diseq(),tt=0){
    out <- geomean(d)
    factor <- 10
    ratios <- c('U48','ThU','RaU','PaU')
    nuclides <- c('U234','Th230','Ra226','Pa231')
    for (i in 1:length(nuclides)){
        ratio <- ratios[i]
        nuclide <- nuclides[i]
        measured <- out[[ratio]]$option>1
        expired <- tt*out$L[nuclide]>10
        equilibrium <- out[[ratio]]$x==1
        deficit <- out[[ratio]]$x<1
        if (equilibrium){
            out[[ratio]]$option <- 0
        } else if (measured & expired){
            out[[ratio]]$option <- 1
            if (deficit) out[[ratio]]$x <- 0
            else out[[ratio]]$x <- 10
        }        
    }
    out
}

check.equilibrium <- function(d=diseq()){
    U48 <- (d$U48$option==0 | all(d$U48$x==1))
    ThU <- (d$ThU$option==0 | all(d$ThU$x==1))
    RaU <- (d$RaU$option==0 | all(d$RaU$x==1))
    PaU <- (d$PaU$option==0 | all(d$PaU$x==1))
    U48 & ThU & RaU & PaU
}

# d only contains one sample
mclean <- function(tt=0,d=diseq(),exterr=FALSE){
    out <- list()
    l38 <- settings('lambda','U238')[1]
    l34 <- settings('lambda','U234')[1]*1000
    l30 <- settings('lambda','Th230')[1]*1000
    l26 <- settings('lambda','Ra226')[1]*1000
    l35 <- settings('lambda','U235')[1]
    l31 <- settings('lambda','Pa231')[1]*1000
    U <- iratio('U238U235')[1]
    out$dPb206U238dl38 <- 0
    out$dPb206U238dl34 <- 0
    out$dPb206U238dl30 <- 0
    out$dPb206U238dl26 <- 0
    out$dPb207U235dl35 <- 0
    out$dPb207U235dl31 <- 0
    d <- fix.diseq(d=d,tt=tt)
    if (check.equilibrium(d=d)){
        out$Pb206U238 <- exp(l38*tt)-1
        out$Pb207U235 <- exp(l35*tt)-1
        out$dPb206U238dt <- exp(l38*tt)*l38
        out$dPb207U235dt <- exp(l35*tt)*l35
        out$d2Pb206U238dt2 <- exp(l38*tt)*l38^2
        out$d2Pb207U235dt2 <- exp(l35*tt)*l35^2
        if (exterr){
            out$dPb206U238dl38 <- tt*exp(l38*tt)
            out$dPb207U235dl35 <- tt*exp(l35*tt)
        }
    } else {
        d$n0['U238'] <- 1/l38
        d$n0['U235'] <- 1/l35
        if (d$U48$option<2){     # initial 234U
            if (d$U48$option==0) out$n0['U234'] <- 1/l34
            else d$n0['U234'] <- d$U48$x/l34
            if (d$ThU$option<2){ # initial 230Th
                if (d$ThU$option==0) d$n0['Th230'] <- 1/l30
                else d$n0['Th230'] <- d$ThU$x/l30
            } else {             # measured 230Th
                nt <- forward(tt=tt,d=d)[c('U238','U234','Th230','U235')]
                nt['Th230'] <- d$ThU$x*nt['U238']*l30/l38 # overwrite
                d$n0['Th230'] <- reverse(tt=tt,mexp=mexp.8405(),nt=nt)['Th230']
            }
        } else {                 # measured 234U
            if (d$ThU$option<2){ # initial 230Th
                nt <- forward(tt=tt,d=d)[c('U238','U234','U235')]
                nt['U234'] <- d$U48$x*nt['U238']*l34/l38 # overwrite
                d$n0['U234'] <- reverse(tt=tt,mexp=mexp.845(),nt=nt)['U234']
                if (d$ThU$option==0) d$n0['Th230'] <- 1/l30
                else d$n0['Th230'] <- d$ThU$x/l30
            } else {             # measured 230Th
                nt <- forward(tt=tt,d=d)[c('U238','U234','Th230','U235')]
                nt['U234'] <- d$U48$x*nt['U238']*l34/l38 # overwrite
                nt['Th230'] <- d$ThU$x*nt['U238']*l30/l38 # overwrite
                d$n0[c('U234','Th230')] <-
                    reverse(tt=tt,mexp=mexp.8405(),nt=nt)[c('U234','Th230')]
            }
        }
        if (d$RaU$option==0) d$n0['Ra226'] <- 1/l26
        else d$n0['Ra226'] <- d$RaU$x/l26
        if (d$PaU$option==0) d$n0['Pa231'] <- 1/l31
        else d$n0['Pa231'] <- d$PaU$x/l31
        d$nt <- forward(tt=tt,d=d)
        dntdt <- forward(tt,d=d,derivative=1)
        d2ntdt2 <- forward(tt,d=d,derivative=2)
        out$Pb206U238 <- d$nt['Pb206']/d$nt['U238']
        out$Pb207U235 <- d$nt['Pb207']/d$nt['U235']
        out$dPb206U238dt <- dntdt['Pb206']/d$nt['U238'] -
            out$Pb206U238*dntdt['U238']/d$nt['U238']
        out$d2Pb206U238dt2 <- d2ntdt2['Pb206']/d$nt['U238'] -
            2*dntdt['Pb206']*dntdt['U238']/d$nt['U238']^2 -
            out$Pb206U238*d2ntdt2['U238']/d$nt['U238'] +
            2*out$Pb206U238*(dntdt['U238']/d$nt['U238'])^2
        out$dPb207U235dt <- dntdt['Pb207']/d$nt['U235'] -
            out$Pb207U235*dntdt['U235']/d$nt['U235']
        out$d2Pb207U235dt2 <- d2ntdt2['Pb207']/d$nt['U235'] -
            2*dntdt['Pb207']*dntdt['U235']/d$nt['U235']^2 -
            out$Pb207U235*d2ntdt2['U235']/d$nt['U235'] +
            2*out$Pb207U235*(dntdt['U235']/d$nt['U235'])^2
        if (exterr){
            K <- get.diseq.K(tt=tt,d=d)
            out$dPb206U238dl38 <- drdl(d=d,K=K,den='U238',num='Pb206',parent='U238')
            out$dPb206U238dl34 <- drdl(d=d,K=K,den='U238',num='Pb206',parent='U234')
            out$dPb206U238dl30 <- drdl(d=d,K=K,den='U238',num='Pb206',parent='Th230')
            out$dPb206U238dl26 <- drdl(d=d,K=K,den='U238',num='Pb206',parent='Ra226')
            out$dPb207U235dl35 <- drdl(d=d,K=K,den='U235',num='Pb207',parent='U235')
            out$dPb207U235dl31 <- drdl(d=d,K=K,den='U235',num='Pb207',parent='Pa231')
        }
    }
    if (tt>0){
        out$Pb207Pb206 <- out$Pb207U235/(U*out$Pb206U238)
        out$dPb207Pb206dt <- (out$dPb207U235dt*out$Pb206U238 -
                              out$dPb206U238dt*out$Pb207U235)/(U*out$Pb206U238^2)
    } else {
        out$Pb207Pb206 <- 0
        out$dPb207Pb206dt <- 0
    }
    if (exterr){
        out$dPb207Pb206dl38 <- -out$dPb206U238dl38*out$Pb207U235/(U*out$Pb206U238^2)
        out$dPb207Pb206dl34 <- -out$dPb206U238dl34*out$Pb207U235/(U*out$Pb206U238^2)
        out$dPb207Pb206dl30 <- -out$dPb206U238dl30*out$Pb207U235/(U*out$Pb206U238^2)
        out$dPb207Pb206dl26 <- -out$dPb206U238dl26*out$Pb207U235/(U*out$Pb206U238^2)
        out$dPb207Pb206dl35 <- out$dPb207U235dl35*out$Pb206U238/(U*out$Pb206U238^2)
        out$dPb207Pb206dl31 <- out$dPb207U235dl31*out$Pb206U238/(U*out$Pb206U238^2)
        out$dPb207Pb206dU <- -out$Pb207Pb206/U
    } else {
        out$dPb207Pb206dl38 <- 0
        out$dPb207Pb206dl34 <- 0
        out$dPb207Pb206dl30 <- 0
        out$dPb207Pb206dl26 <- 0
        out$dPb207Pb206dl35 <- 0
        out$dPb207Pb206dl31 <- 0
        out$dPb207Pb206dU <- 0
    }
    out
}

get.diseq.K <- function(tt=0,d=diseq()){
    nl <- length(d$L)
    out <- matrix(0,nl,nl)
    colnames(out) <- names(d$L)
    rownames(out) <- names(d$L)
    for (i in 1:nl){
        for (j in 1:nl){
            if (i==j){
                out[i,j] <- tt*exp(-d$L[i]*tt)
            } else if (d$L[i]==d$L[j]){
                # do nothing
            } else {
                out[i,j] <- (exp(-d$L[i]*tt)-exp(-d$L[j]*tt))/(d$L[j]-d$L[i])
            }
        }
    }
    out
}
drdl <- function(tt=0,K=matrix(0,8,8),d=diseq(),
                 num='Pb206',den='U238',parent='Th230'){
    # 1. create matrix derivative
    i <- which(names(d$L)%in%parent)
    nl <- length(d$L)
    dAdl <- matrix(0,nl,nl)
    dAdl[c(i,i+1),i] <- c(-1,1)
    H <- d$Qinv %*% dAdl %*% d$Q
    P <- H * K
    dntdl <- as.vector(d$Q %*% P %*% d$Qinv %*% d$nt)
    names(dntdl) <- names(d$L)
    # 2. derivative of the ratio
    out <- (d$nt[den]*dntdl[num]-
            d$nt[num]*dntdl[den])/d$nt[den]^2
    out
}

diseq.75.misfit <- function(tt,x,d){
    (x - subset(age_to_Pb207U235_ratio(tt,d=d),select='75'))^2
}
diseq.68.misfit <- function(tt,x,d){
    (x - subset(age_to_Pb206U238_ratio(tt,d=d),select='68'))^2
}
get.76.misfit <- function(tt,x,d=diseq()){
    (x - subset(age_to_Pb207Pb206_ratio(tt=tt,d=d),select='76'))^2
}
